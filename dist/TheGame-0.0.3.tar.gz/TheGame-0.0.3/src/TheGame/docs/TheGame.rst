thegame module
=============

.. automodule:: thegame
   :members:
   :undoc-members:
   :show-inheritance: