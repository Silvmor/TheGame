# TheGame - A multiplayer game built in python
Once you have the game with you, there are only two steps:
- Get the Server up and running `python3 Server.py`
- Get the Server's IP
- Run the Clients on separate machines `python3 clients.py`
- Enter the Server IP addresses and start the game.